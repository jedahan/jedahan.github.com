# vercel autocomplete

The goal of this interview is for you to create a User Interface that performs autocomplete against a dictionary of words using an API endpoint that you'll also write. The frontend interface (as simple as an input in the middle of a page) displays matches based on user input (think of how google autocomplete results look/work as an example). So if the user types “foo” you'll want to look up results using your API and display the results such that the user could select one. The only thing selection absolutely needs to do is `console.log` the chosen result item. You should avoid using external libraries that attempt to solve too much of the problem — they may restrict your being able to show us where you shine.

# Questions

What is a reasonable number of results to show in completion?
Should we filter client-side?
Should we start sending results immediately or after 1-2 characters?
(regardless of debounce)

# TODO

## backend

add timing
rename index

## frontend

serve up some html with input box

fetch (with the current input box text)
  add debounce

write a component to render the autocomplete list



