import Koa from 'koa'
import Router from '@koa/router'
import serve from 'koa-files'

import { complete } from './autocomplete'

const app = new Koa()
const router = new Router()

router.get('/complete', (ctx) => {
  const query = ctx.request.query
  if (query.prefix == null) return
  if (Array.isArray(query.prefix)) throw new Error('Multiple Prefixes not supported at this time')
  if (Array.isArray(query.limit)) throw new Error('Limit must be a number, found array')
  const limit = query.limit != null ? parseInt(query.limit) : undefined
  ctx.body = { words: complete(query.prefix, limit) }
})

app
  .use(serve('build'))
  .use(router.routes())
  .use(router.allowedMethods())

app.listen(3000)
