import * as React from 'react'
import { useState } from 'react'
import ReactDOM from 'react-dom'
import { createRoot } from 'react-dom/client'
import * as Server from 'react-dom/server'
import useSWR from 'swr'

// type Completions = Record<'completions', string[]>
// const fetcher: Fetcher<string, Completions> =

// @ts-ignore
const fetcher = async (path: string) => fetch(path).then(res => res.json())

const SearchList = () => {
  const [prefix, setPrefix] = useState<string>('')
  const { data: completions, error } =
    useSWR(prefix.length > 0 ? `:3000?prefix=${prefix}` : null, fetcher)

  // TODO: add debounce

  return (
  <>
    <input
      name='prefix'
      type='text'
      onChange={(event) => {
        const trimmed = event.currentTarget.value.trim()
        event.preventDefault()
        setPrefix(trimmed)
      }}
      value={prefix}
    />

    {error != null && (
      <div>Error {error}</div>
    )}
    {completions !== undefined && completions?.completions?.length > 0 &&
    (
      <ul>
        {completions.completions.map((completion: string, idx: number) => <li key={idx}> {completion} </li>)}
      </ul>
    )}
  </>
  )
}

const container = document.getElementById('root')
const root = createRoot(container!)
root.render(<SearchList />)
