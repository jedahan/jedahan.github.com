import { readFile } from 'fs'

let wordlist: string[] = []

readFile('./wordlist.txt', 'utf8', (error, words) => {
  if (error != null) throw new Error(error.message)
  wordlist = words.split('\n')
})

export function complete (prefix: string, limit: number = 100): string[] {
  return wordlist
    .filter((word) => word.startsWith(prefix))
    .slice(0, limit)
}
